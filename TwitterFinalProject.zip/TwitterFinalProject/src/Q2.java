

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.logging.Logger;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Q2
 */
@WebServlet("/Q2")
public class Q2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Q2() {
        super();
        // TODO Auto-generated constructor stub
    }
    static Logger logger;
    private static Connection getRemoteConnection() throws SQLException {
    	 
    	String dbName = "twitterdb";
    	  String userName = "ksolanki";
    	  String password = "50lank1402";
    	  String hostname = "twitterinstance.cabmso8gz1o9.us-west-2.rds.amazonaws.com";
    	  String port = "3306";
    	  String jdbcUrl = "jdbc:mysql://" + hostname + ":" +
    	    port + "/" + dbName + "?user=" + userName + "&password=" + password;
    	  
    	  // Load the JDBC driver
    	  try {
    	    System.out.println("Loading driver...");
    	    Class.forName("com.mysql.jdbc.Driver");
    	    System.out.println("Driver loaded!");
    	  } catch (ClassNotFoundException e) {
    	    throw new RuntimeException("Cannot find the driver in the classpath!", e);
    	  }
    	  
    	  Connection conn = null;
    	  try {
    	System.out.println(jdbcUrl);
    	  conn = DriverManager.getConnection(jdbcUrl);
    	  return conn;
    	  }
    	  catch (SQLException ex) {
    		    // Handle any errors
    		    System.out.println("SQLException: " + ex.getMessage());
    		    System.out.println("SQLState: " + ex.getSQLState());
    		    System.out.println("VendorError: " + ex.getErrorCode());
    		  } 
        return null;
      }

	
    Statement statement = null;
	ResultSet resultSet = null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter output = response.getWriter();
		Date date = new Date();
		SimpleDateFormat timestamp = new SimpleDateFormat("HH:mm:ss");
	    String created_at = "%";
	    created_at = created_at+timestamp.format(date);
	    output.println("time is" +created_at);
	    try {
	    	
			Connection con = getRemoteConnection();
			PreparedStatement ps=con.prepareStatement("select * from q2 where created_at LIKE ?");  
	    	ps.setString(1,created_at); 
			
	    	resultSet = ps.executeQuery();
			response.setContentType("text/html");
			response.setCharacterEncoding("UTF-8");
			output.println("<html>");
			output.println("<head>");
			output.println("<title>Query 2 - Results </title>");
			output.println("</head>");
			output.println("<body bgcolor=\"white\">");
			  
			
			while(resultSet.next()){
				long tweet_id = resultSet.getLong("tweet_id");
				String text = resultSet.getString("text");
				
				
				
				
				output.println("<p>");
				output.println(tweet_id + ":" + text);
				output.println("</p>");
				response.setIntHeader("Refresh", 10);
			}
			
			output.println("</body>");
			output.println("</html>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */

}
